public class Main {
    public static void main(String[] args) {
        int i1 = 2;
        int i2 = 5;
        long l1 = 4;
        long l2 = 2;
        double d1 = 6;
        double d2 = 3;
        float f1 = 8;
        float f2 = 4;
        int der = i1 + i2;
        long ser = l1 + l2;
        long wer = i1+l1;
        float fer = i1 + f1;
        double ler = i1 + d1;
        double ker = l1 + d1;
        System.out.println(der);
        System.out.println(ser);
        System.out.println(wer);
        System.out.println(fer);
        System.out.println(ler);
        System.out.println(ker);





    }
}