public class Main {
    public static void main(String[] args) {
        byte x1 = 127;
        System.out.println(x1);
        x1++;
        System.out.println(x1);
    }
}