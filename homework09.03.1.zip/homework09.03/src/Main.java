public class Main {
    static final char jb = 'j' ;
    static final char db = 'd' ;
    public static void main(String[] args) {
        boolean logid = true;
        byte log1 = 10;
        short log2 = 2222;
        int log3 = 1234;
        long log4 = 3l;
        float log5 = 1.3f;
        double log6 = 1.55;
        char log7 = jb;
        System.out.println(logid);
        System.out.println(log1);
        System.out.println(log2);
        System.out.println(log3);
        System.out.println(log4);
        System.out.println(log5);
        System.out.println(log6);
        System.out.println(log7);
        log3 = log3 + 2;
        logid = false;
        log7 = db;
        System.out.println(log3);
        System.out.println(logid);
        System.out.println(log7);

    }

}