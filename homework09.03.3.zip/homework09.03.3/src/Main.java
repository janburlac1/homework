public class Main {
    public static void main(String[] args) {
        int kol = 5;
        int lol = 4;
        int hol = 15;
        int dol = 3;
        int rer = kol % lol;
        int der = hol % dol;
        System.out.println(rer);
        System.out.println(der);
        System.out.println();
        boolean x1 = 2 % 2 == 0;
        boolean x2 = 7 % 2 == 0;
        boolean x3 = 13 % 2 == 0;
        boolean x4 = 14 % 2 == 0;
        System.out.println(x1);
        System.out.println(x2);
        System.out.println(x3);
        System.out.println(x4);
        System.out.println();
        int wq = 14 % 10;
        System.out.println(wq);



    }
}