public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("");
        System.out.println("Lionel Messi");
        System.out.println("31 Years");
        System.out.println("170 cm");
        System.out.println();
        System.out.println("Eden Hazard");
        System.out.println("32 Years");
        System.out.println("172 cm");
        System.out.println();
        System.out.println("Mesut Ozil");
        System.out.println("37 Years");
        System.out.println("180 cm");
        System.out.println();
        System.out.printf("3.22 4.33 5.44");
        System.out.println();
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println("");
        System.out.print("I");
        System.out.print("       I");
        System.out.println();
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");


    }

}