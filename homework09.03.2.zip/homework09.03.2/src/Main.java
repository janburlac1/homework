public class Main {
    public static void main(String[] args) {
        int war = 10;
        int dor = 15;
        int fet = war + dor;
        System.out.println(fet);
        System.out.println();
        int der = war - dor;
        int ser = war * dor;
        int ger = war / dor;
        System.out.println(der);
        System.out.println(ser);
        System.out.println(ger);
        int ker = war % dor;
        System.out.println(ker);
    }
}